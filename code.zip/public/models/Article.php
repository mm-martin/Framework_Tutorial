<?php
class Article extends Model
{
	
}